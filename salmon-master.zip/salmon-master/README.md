**Salmon** an app for salary monitoring on a daily/monthly/weekly basis.

### Demo

The demo is available via https://etherity.shinyapps.io/salmon/

### Usage

1. Download the project
2. Schedule running `weekly.R` on a daily/weekly/monthly basis
3. Use the shiny app to observe the results

### License
[CC BY-NC-SA 3.0](https://creativecommons.org/licenses/by-nc-sa/3.0/legalcode)

![](https://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png)